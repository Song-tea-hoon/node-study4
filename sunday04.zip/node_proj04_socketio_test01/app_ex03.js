var http = require('http');
var express = require('express');
var app = express();
var socketio = require('socket.io');

var server = http.createServer(app);
server.listen(3000, function() {
    console.log('서버가 실행되었습니다~');
});

var io = socketio.listen(server);

io.sockets.on('connection', function(socket) {
    console.log('connection ...');
    
    io.sockets.emit('this', {will: 'be received by everyone'});
    
    socket.on('private message', function(from, msg) {
        console.log('private message by ', from, 'saying ', msg);
    });
    
    socket.on('disconnect', function() {
        console.log('disconnected...')
        io.sockets.emit('user desconnected');
    });
});