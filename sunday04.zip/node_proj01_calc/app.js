const http = require('http');
const express = require('express');
const app = express();
const router = express.Router();
const cors = require('cors');

app.use(cors());

// 4칙연산 처리가 되도록 한다.
// http://localhost:8888/plus/10/5
router.route("/plus/:a/:b").get((req, res)=>{
    let a = req.params.a; // 문자열 타입
    let b = req.params.b;
    let result = parseInt(a) + parseInt(b); // number타입
    res.end(String(result));
});

router.route("/minus/:a/:b").get((req, res)=>{
    let a = req.params.a; // 문자열 타입
    let b = req.params.b;
    res.end(String( parseInt(a) - parseInt(b) ));
});

router.route("/mult/:a/:b").get((req, res)=>{
    res.end(String( parseInt(req.params.a) * parseInt(req.params.b) ));
});

router.route("/mult/:a/:b").get((req, res)=>{
    res.end(String( Number(req.params.a) / Number(req.params.b) ));
});


app.use('/', router);
const server = http.createServer(app);
server.listen(8888, ()=>{
    console.log("http://localhost:8888 실행 중...");
});